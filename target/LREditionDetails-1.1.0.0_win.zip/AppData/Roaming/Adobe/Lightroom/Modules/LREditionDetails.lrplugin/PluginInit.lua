PluginInit = {
	pluginID = "at.homebrew.lreditiondetails",
}
