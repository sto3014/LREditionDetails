#!/usr/bin/env bash
CP="$HOME/Library/Application Support/QRGen/QRGen-1.0.0.0.jar:$HOME/Library/Application Support/QRGen/core-3.4.0.jar"
export CP
java -cp "$CP" at.homebrew.QRGen "$@"
